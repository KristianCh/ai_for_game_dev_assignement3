using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blackboard
{
    public AbstractPlayer HumanPlayer;
    public List<Vector2Int>[,,,] PathsCache;
    public CollectibleItem[,] CollectiblesAtLocations;

    public static Blackboard Instance;

    public Blackboard()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }
}
