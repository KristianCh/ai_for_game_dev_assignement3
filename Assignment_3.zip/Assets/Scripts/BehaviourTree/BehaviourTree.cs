using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BehaviourTree
{
    public AbstractNode Root;
    public AbstractNode CurrentRoot;
    public ActionNode CurrentAction;
    public Vector2Int CurrentActionDestination;

    private bool WasRootSet = false;

    public Vector2Int Evaluate()
    {
        if (!WasRootSet)
        {
            WasRootSet = true;
            CurrentRoot = Root;
        }

        AbstractNode currentNode = CurrentRoot;
        
        while (currentNode.NodeType != NodeType.Action)
        {
            currentNode = currentNode.GetNextNode();
        }
        CurrentActionDestination = currentNode.GetActionDestination();
        return CurrentActionDestination;
    }

    public bool CheckFail()
    {
        if (CurrentAction != null)
        {
            if (CurrentAction.TargetItemType == CollectibleItemType.None)
            {
                return false;
            }
            if (CurrentAction.TargetItemType == CollectibleItemType.Any && Blackboard.Instance.CollectiblesAtLocations[CurrentActionDestination.x, CurrentActionDestination.y] != null)
            {
                return false;
            }
            if (Blackboard.Instance.CollectiblesAtLocations[CurrentActionDestination.x, CurrentActionDestination.y] != null &&
                CurrentAction.TargetItemType == Blackboard.Instance.CollectiblesAtLocations[CurrentActionDestination.x, CurrentActionDestination.y].Type)
            {
                return false;
            }
        }
        return true;
    }
}
