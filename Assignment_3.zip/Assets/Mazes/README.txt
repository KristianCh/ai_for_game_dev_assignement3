Do you want to define your own maze?
No problem, it is really easy.

The only thing you need is to remember these four characters:
|  # = wall
|  - = free tile
|  A = spawn position of the AI players
|  P = spawn position of the human player

Also, the maze must have square/rectangular shape, i.e., all rows must be of same length.